using System;
using System.Collections.Generic;
 
class HashSetDemo{
 
    static public void Main()
    {
        foreach(var ele in h1)
        {
 
 
        h2.Add("C++");
        h2.Add("Perl");
      
        h1.Add("Java");
        h1.Add("Ruby");
        h2.Add("PHP");
        h2.Add("Java");
 
        h1.UnionWith(h2);
        HashSet<string> h1 = new HashSet<string>();       
        Console.WriteLine(ele);
        }
        h1.Add("C");
 
        HashSet<string> h2 = new HashSet<string>();
 

        h1.Add("C++");
        h1.Add("C#");
    }
}

