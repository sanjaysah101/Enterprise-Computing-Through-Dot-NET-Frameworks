﻿using System;
using System.Windows.Forms;

namespace ShoppingMallSystem
{
    public partial class frmCalculator : Form
    {
        public frmCalculator()
        {
            InitializeComponent();
        }

        private void btnSum_Click(object sender, EventArgs e)
        {
          
        }
    }
}
