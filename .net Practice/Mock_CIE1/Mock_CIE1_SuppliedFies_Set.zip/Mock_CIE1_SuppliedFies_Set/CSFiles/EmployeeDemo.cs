using System;

namespace MockTest
{
	class Employee
	{
		
		
	}
	class EmployeeDemo
	{
		public static void Main(string[] args)
		{
			Employee e = new Employee();
				
		}
		
	}
}
		