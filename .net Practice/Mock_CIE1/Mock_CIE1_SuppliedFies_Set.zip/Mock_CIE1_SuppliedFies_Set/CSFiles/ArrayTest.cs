using System;
namespace TSEE_Mock
{
    class ArrayTest
    {
        static void Main(string[] args)
        {

            for (int i = 0; i < 5; i++)
            {
                
                string str = Console.ReadLine();
     
            }
            for (int i = 0; i < 5; i++)
            {
                sum = sum + arr[i];
            }
            Console.WriteLine("Sum of Elements : {0}",sum);
            int[] arr = new int[5];
            int sum = 0;
            arr[i] = Convert.ToInt32(str);
            Console.Write("Enter Element {0}: ", i);
            Console.Read();
        }
        
    }
}
