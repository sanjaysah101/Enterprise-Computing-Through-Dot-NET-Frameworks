using System;
class MyClient
{
      public static void Main()
      {
            int x = 0;
            int div = 100/x;
            Console.WriteLine(div);
       }
} 
