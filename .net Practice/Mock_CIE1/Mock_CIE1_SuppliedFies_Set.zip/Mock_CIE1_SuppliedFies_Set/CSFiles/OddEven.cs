using System;

namespace ConsoleApplication1
{
    class OddEven
    {
        static void Main(string[] args)
        {
            int x;
            Console.WriteLine("Enter Number : ");
            x = Convert.ToInt32(str);
            Console.WriteLine("Number is Even");
            else
            string str = Console.ReadLine();
            if (x % 2 == 0)
            Console.WriteLine("Number is Odd");
        }
    }
}
